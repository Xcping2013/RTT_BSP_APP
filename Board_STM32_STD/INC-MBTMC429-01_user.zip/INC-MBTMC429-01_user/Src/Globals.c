
#include "main.h"
//! Motor configuration data
TMotorConfig MotorConfig[N_O_MOTORS]=
{
  1120,   //!< VMax
  600,    //!< AMax
  7,      //!< Pulsediv
  7,      //!< Rampdiv
};

//TMotorConfig MotorConfig[N_O_MOTORS]=
//{
//  1000,   //!< VMax
//  500,    //!< AMax
//  2,      //!< Pulsediv
//  3,      //!< Rampdiv
//  255,    //!< IRun
//  32,     //!< IStandby
//  0,      //!< StallVMin
//  0,      //!< FreewheelingDelay
//  200     //!< SettingDelay
//};

