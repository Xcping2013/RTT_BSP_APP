#ifndef __GLOBALS_H
#define __GLOBALS_H

extern UCHAR    SpeedChangedFlag[N_O_MOTORS];
extern UCHAR 		ActualMotor; 
extern TMotorConfig MotorConfig[3];

#endif

