#include <stdlib.h>
#include "main.h"
#include "bits.h"
#include <string.h>

#include "Commands.h"
#include "UART.h"

uint8_t  CommmandLine_IAC_LCR(char *Commands)
{
	return 0;
}
//
