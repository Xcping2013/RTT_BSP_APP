#ifndef __LIDOPEN_H
#define __LIDOPEN_H

extern  uint8_t	KeyS_actOK_LidOpen;
extern 	uint8_t KeyS_actEN_LidOpen;

void RampInit_Lidopen(void);
void KeyS_act_LIDOPEN(void);

#endif
