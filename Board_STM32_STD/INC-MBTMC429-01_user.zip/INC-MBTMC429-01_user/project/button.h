#ifndef __BUTTON_H
#define __BUTTON_H

void 	   RampInit_Button(void);

#endif
